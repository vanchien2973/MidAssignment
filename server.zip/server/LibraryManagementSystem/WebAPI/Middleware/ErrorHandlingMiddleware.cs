namespace WebAPI.Middleware;

public class ErrorHandlingMiddleware
{
    
}