namespace WebAPI.Middleware;

public class RequestLoggingMiddleware
{
    
}