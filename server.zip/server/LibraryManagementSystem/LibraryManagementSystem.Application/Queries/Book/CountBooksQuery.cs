using MediatR;

namespace LibraryManagementSystem.Application.Queries.Book
{
    public class CountBooksQuery : IRequest<int>
    {
    }
} 