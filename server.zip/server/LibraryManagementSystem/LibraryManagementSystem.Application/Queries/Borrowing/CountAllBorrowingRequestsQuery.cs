using MediatR;

namespace LibraryManagementSystem.Application.Queries.Borrowing;

public class CountAllBorrowingRequestsQuery : IRequest<int>
{
} 