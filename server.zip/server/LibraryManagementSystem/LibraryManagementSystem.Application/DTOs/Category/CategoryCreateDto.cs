namespace LibraryManagementSystem.Application.DTOs.Category;

public class CategoryCreateDto
{
    public string CategoryName { get; set; }
    public string Description { get; set; }
}