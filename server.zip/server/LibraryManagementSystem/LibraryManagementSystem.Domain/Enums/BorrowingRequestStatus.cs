namespace LibraryManagementSystem.Domain.Enums;

public enum BorrowingRequestStatus
{
    Waiting = 1,
    Approved = 2,
    Rejected = 3
}