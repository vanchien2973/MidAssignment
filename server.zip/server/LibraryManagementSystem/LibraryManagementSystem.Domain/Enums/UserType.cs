namespace LibraryManagementSystem.Domain.Enums;

public enum UserType
{
    NormalUser = 1,
    SuperUser = 2
}