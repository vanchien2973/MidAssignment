namespace LibraryManagementSystem.Domain.Enums;

public enum BorrowingDetailStatus
{
    Borrowing = 1,
    Returned = 2,
    Extended = 3
}