using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;

namespace LibraryManagementSystem.Infrastructure.Data.Context;

public class LibraryDbContextFactory : IDesignTimeDbContextFactory<LibraryDbContext>
{
    public LibraryDbContext CreateDbContext(string[] args)
    {
        // Lấy thư mục gốc của dự án
        var basePath = Directory.GetCurrentDirectory();
        
        // Đọc cấu hình từ file appsettings.json
        var configuration = new ConfigurationBuilder()
            .SetBasePath(basePath)
            .AddJsonFile("appsettings.json")
            .AddJsonFile($"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Development"}.json", optional: true)
            .Build();
            
        // Lấy chuỗi kết nối từ cấu hình
        var connectionString = configuration.GetConnectionString("DefaultConnection");
        
        // Tạo DbContextOptions với SQL Server và chuỗi kết nối
        var optionsBuilder = new DbContextOptionsBuilder<LibraryDbContext>();
        optionsBuilder.UseSqlServer(connectionString);
        
        return new LibraryDbContext(optionsBuilder.Options);
    }
}